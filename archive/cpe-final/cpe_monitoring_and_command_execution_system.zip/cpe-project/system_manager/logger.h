// logger header file

#ifndef LOGGER_H
#define LOGGER_H

#include <stdarg.h>

void log_message(const char *format, ...);

#endif