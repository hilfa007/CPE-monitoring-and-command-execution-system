// TCP socket connection to device agent header file 

#ifndef DEVICE_AGENT_CLIENT_H
#define DEVICE_AGENT_CLIENT_H

#include "metrics.h"


int send_metrics_to_agent(Metrics m);

#endif
